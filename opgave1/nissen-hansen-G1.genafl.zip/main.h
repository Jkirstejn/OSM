#ifndef _MAIN_H
#define _MAIN_H

#include "bintree.h"
#include "dlist.h"

int compare(void*, void*);
int main();

#endif
